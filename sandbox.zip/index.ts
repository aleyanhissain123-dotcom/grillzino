import express from "express";
import path from "path";

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// 🔐 TEMP: paste your NEW API key here (do NOT post it anywhere)
const OPENAI_API_KEY = "YOUR_NEW_API_KEY";

const SYSTEM_PROMPT = `
You are a professional GCSE Science tutor specialising in AQA Separate Science (Higher Tier).

Rules:
- Explain concepts clearly and step-by-step.
- Use GCSE-level language.
- Include key terms.
- Give exam tips.
- Highlight common mistakes.
- Ask 1–2 check questions.
`;

app.post("/api/tutor", async (req, res) => {
  try {
    const { message, mode, topic } = req.body as {
      message?: string;
      mode?: string;
      topic?: string;
    };

    if (!message) {
      return res.status(400).json({ error: "Missing message" });
    }

    // 🎓 Lesson Mode
    let systemPrompt = SYSTEM_PROMPT;

    if (mode === "lesson") {
      systemPrompt = `
You are a confident GCSE Science tutor delivering a structured 30-minute lesson on ${topic}.

Structure:
1. Diagnostic starter question.
2. Clear explanation of the topic.
3. Worked example (step-by-step if maths).
4. Common exam mistakes.
5. 3 short practice questions.
6. One 6-mark exam question.
7. Self-mark checklist.

After each section ask:
"Ready to continue? (yes/no)"

Be motivating and structured.
`;
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer 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`,
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        input: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message },
        ],
      }),
    });

    const data: any = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "OpenAI error",
      });
    }

    let reply = data.output_text;

    if (!reply && Array.isArray(data.output)) {
      reply = data.output
        .flatMap(
          (item: any) =>
            item.content?.map((c: any) => c.text).filter(Boolean) || []
        )
        .join("\n");
    }

    res.json({ reply: reply || "No reply received." });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(3000, () => console.log("Server running on port 3000"));
